		
<ul class="navlist">
	<li><a href="index.php" class="home">Home</a></li>
	<li><a href="products.php" class="products">Products</a></li>
	<li><a href="company.php" class="comp">Company</a></li>
	<li><a href="faq.php" class="faq">Faq's</a></li>
	<li><a href="contact.php" class="con">Contact</a></li>
	<li><a href="news/" class="news">News</a></li>
</ul>
 			
 		
