<div id="footer">
			<div id="foot-wrap">
				
					<div id="foot-nav">
							<?php include("menu.php"); ?>
							
									<br/>
								
									<img src="images/layout/crn.jpg" border="0"/>
									
							
							
							<p>&copy; Biotron Laboratories, All Rights Reserved.</p>				
							
						</div>
						<!-- /footnav-->
						
						<div id="address">
						<strong>Address:</strong> 750 North 1250 West Centerville, UT 84014 <br>
						 <strong>Phone:</strong> 801-298-8438   <strong>Fax:</strong> 801-298-8800<br>
						 <strong>Email:</strong> <a href="mailto:info@biotronlabs.com" target="_blank">Info@biotronlabs.com</a><br/>
						<!-- <img src="images/layout/linkedin.png" border="0"/>-->
						<!--  <img src="images/layout/twitter.png" border="0"/>-->
						 <!-- <img src="images/layout/blog.png" border="0"/>-->
						
						</div>
			</div>
			
	</div>
